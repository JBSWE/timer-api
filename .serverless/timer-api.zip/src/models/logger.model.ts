export interface LoggerContext {
  requestId: string
  version?: string
  usr?: string
  corr?: string
}
