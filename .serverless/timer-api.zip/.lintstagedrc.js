module.exports = {
  "src/**/*.ts": [
    "npm run lint:fix",
  ],
};
