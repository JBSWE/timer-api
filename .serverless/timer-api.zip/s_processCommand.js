
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'jackburke',
  applicationName: 'timer-api',
  appUid: 'hmjgFl80ZfMxWGPBBY',
  orgUid: '5830ebf0-9a6b-4db6-87f3-c6ddef125ec6',
  deploymentUid: '352e3d59-1284-41f2-ad4a-d5f7532a533d',
  serviceName: 'timer-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'timer-api-dev-processCommand', timeout: 6 };

try {
  const userHandler = require('./dist/handlers/commandHandler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.processCommand, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}